<div class="row">
	<div class="col-sm-3 col-md-3 col-lg-3 pull-right" id="main-login-signup">
		<?php $this->load->view('site/login-form.php')?>
		<br><br>
		<?php $this->load->view('site/register-form.php')?>
	</div>
</div>