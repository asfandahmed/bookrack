<div class="row">
	<div class="col-sm-offset-3 col-md-offset-3 col-lg-offset-3 col-sm-5 col-md-5 col-lg-5" id="login-form-page">
		<?php $this->load->view('site/login-form.php')?>
	</div>
</div>