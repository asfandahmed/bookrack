	</div>
	<div class="modal fade" id="contentModal" tabindex="-1" role="dialog" aria-labelledby="inbox" aria-hidden="true">
	  
	</div>

<script src="<?=base_url('assets/js/bootstrap.minGroupsMY.js')?>"></script>
<script src="<?=base_url('assets/js/scriptGroupsMY.js')?>"></script>
<!--<script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>-->
<script src="<?=base_url('assets/js/jquery-ui-1.11.2.custom/jquery-ui.min.js')?>"></script>
<script src="<?=base_url('assets/js/scroll.js')?>"></script>
<script src="<?=base_url('assets/js/script.js')?>"></script>
<script src="<?=base_url('assets/js/jquery.capSlide.min.js')?>"></script>
<script src="<?=base_url('assets/js/humane.js')?>"></script>
<script src="<?=base_url('assets/js/jquery.form.min.js')?>"></script>
  </body>
<!-- page rendered in {elapsed_time} seconds. Memory used {memory_usage} -->

</html>