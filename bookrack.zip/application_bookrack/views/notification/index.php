<div class="row">
	<div  class="middle-content  col-xs-offset-1 col-sm-offset-1 col-md-offset-1 col-lg-offset-1 col-xs-7 col-sm-7 col-md-7 col-lg-7">
		<div class="row" style="background-color:rgb(245, 245, 245); font-size:0.9em;">
			<div class="col-xs-9 col-sm-9 col-md-9 col-lg-9">
				<a href="#"><span style="font-weight:bold"></span></a> sent you a borrow request at 
			</div>
		</div>	
		<br>
	</div>
</div>