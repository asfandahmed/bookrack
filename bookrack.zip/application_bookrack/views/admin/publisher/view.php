<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12">
	</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
		<ul class="list-group">
			<li class="list-group-item"><b>Company</b> <?=isset($company)?$company:""?></li>
		</ul>
	</div>
	</div>