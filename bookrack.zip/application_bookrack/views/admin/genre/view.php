<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12">
	</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
		<ul class="list-group">
			<li class="list-group-item"><b>Name</b> <?=isset($name)?ucfirst($name):""?></li>
		</ul>
	</div>
	</div>