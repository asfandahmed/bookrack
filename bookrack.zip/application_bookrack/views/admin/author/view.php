<div class="row">
	<div class="col-sm-12 col-md-12 col-lg-12">
	</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
		<ul class="list-group">
			<li class="list-group-item"><b>Name</b> <?=isset($name)?$name:""?></li>
			<li class="list-group-item"><b>Address</b> <p><?=isset($address)?$address:""?></p></li>
			<li class="list-group-item"><b>Contact</b> <?=isset($contact)?$contact:""?></li>
		</ul>
	</div>
</div>