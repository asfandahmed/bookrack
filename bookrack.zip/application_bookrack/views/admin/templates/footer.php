	</div>
	<!-- page rendered in {elapsed_time} seconds-->
	</body>

<script type="text/javascript" src="<?php echo base_url("assets/js/bootstrap.js"); ?>"></script>
<script src="<?=base_url('assets/js/jquery-ui-1.11.2.custom/jquery-ui.min.js')?>"></script>
<script src="<?=base_url('assets/js/admin_script.js')?>"></script>
</html>